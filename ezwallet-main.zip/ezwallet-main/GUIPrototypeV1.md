# Graphical User Interface Prototype  - CURRENT

Authors: Arianna Valenza, Salvatore Acquaviva

Date: 13.04.23

Version: 1.3

\<Report here the GUI that you propose for EZWallet in CURRENT form, as received by teachers. You are free to organize it as you prefer. A suggested presentation matches the Use cases and scenarios defined in the Requirement document. The GUI can be shown as a sequence of graphical files (jpg, png)  >
![](2023-04-13-12-34-30.png)
![](2023-04-13-12-34-51.png)
![](2023-04-20-10-41-51.png)
![](2023-04-20-10-42-09.png)
![](2023-04-20-10-42-23.png)
![](2023-04-20-10-42-37.png)